# -*- coding: utf-8 -*-
"""
Bước 8.1 - Phân tích kết quả ghép cặp từ bước 6
Mục tiêu: Hiển thị chi tiết và đánh giá các cặp ghép tự động
Input:
    - output/matched_pairs.csv: File kết quả từ bước 6
    - data/answer_key_sample.csv: File đáp án để so sánh
    - data/gl_entries.csv, data/bank_stmt.csv: để tính tổng giao dịch
Output:
    - Danh sách chi tiết các cặp matched
    - Thống kê tổng hợp (KPIs)
    - Phân tích chất lượng ghép
"""

import pandas as pd
from pathlib import Path
from datetime import datetime

# === THIẾT LẬP ĐƯỜNG DẪN ===
script_dir = Path(__file__).resolve().parent
root_dir = script_dir.parent
data_dir = root_dir / "data"
output_dir = root_dir / "output"

# Đảm bảo thư mục output tồn tại
output_dir.mkdir(parents=True, exist_ok=True)

# === TỆP DỮ LIỆU ===
MATCHED_FILE = output_dir / "matched_pairs.csv"
ANSWER_KEY_FILE = data_dir / "answer_key_sample.csv"
GL_FILE = data_dir / "gl_entries.csv"
BANK_FILE = data_dir / "bank_stmt.csv"
KPI_REPORT_FILE = output_dir / "kpi_report_8.1.csv"
KPI_DETAILS_FILE = output_dir / "kpi_details_8.1.csv"

def calculate_kpi(matched_df, truth_df, total_transactions):
    """Tính Auto-match rate, Precision, Recall"""
    # Lọc MATCH
    matched_only = matched_df[matched_df['match_type'] == 'MATCH']

    # Auto-match rate = MATCH / tổng giao dịch GL
    auto_match_rate = len(matched_only) / total_transactions * 100 if total_transactions > 0 else 0

    # True positives = MATCH đúng theo answer key
    true_matches = pd.merge(matched_only, truth_df, on=['bank_ref', 'gl_doc'], how='inner')
    tp = len(true_matches)
    predicted_match_count = len(matched_only)
    actual_match_count = len(truth_df)

    # Precision: tp / predicted
    precision = tp / predicted_match_count * 100 if predicted_match_count > 0 else 0

    # Recall: tp / actual
    recall = tp / actual_match_count * 100 if actual_match_count > 0 else 0

    return auto_match_rate, precision, recall, true_matches

def generate_details(matched_df, truth_df):
    """Tạo chi tiết từng cặp MATCH / FALSE_POSITIVE / FALSE_NEGATIVE"""
    details = []

    # MATCH đúng
    true_matches = pd.merge(matched_df[matched_df['match_type']=='MATCH'], truth_df,
                            on=['bank_ref','gl_doc'], how='inner')
    for _, row in true_matches.iterrows():
        details.append({
            'bank_ref': row['bank_ref'],
            'gl_doc': row['gl_doc'],
            'status': 'TRUE_POSITIVE',
            'reason': 'Ghép đúng theo answer key'
        })

    # MATCH sai
    matched_only = matched_df[matched_df['match_type']=='MATCH']
    false_matches = matched_only.merge(truth_df, on=['bank_ref','gl_doc'], how='left', indicator=True)
    false_matches = false_matches[false_matches['_merge']=='left_only']
    for _, row in false_matches.iterrows():
        details.append({
            'bank_ref': row['bank_ref'],
            'gl_doc': row['gl_doc'],
            'status': 'FALSE_POSITIVE',
            'reason': 'Ghép không khớp với answer key'
        })

    # Bỏ sót (FALSE_NEGATIVE)
    missed_matches = truth_df.merge(matched_only, on=['bank_ref','gl_doc'], how='left', indicator=True)
    missed_matches = missed_matches[missed_matches['_merge']=='left_only']
    for _, row in missed_matches.iterrows():
        details.append({
            'bank_ref': row['bank_ref'],
            'gl_doc': row['gl_doc'],
            'status': 'FALSE_NEGATIVE',
            'reason': 'Cặp ghép đúng bị bỏ sót'
        })

    return pd.DataFrame(details)

def main():
    start_time = datetime.now()
    print("\n=== BƯỚC 8.1: PHÂN TÍCH KẾT QUẢ GHÉP CẶP ===")

    # Kiểm tra file
    for f in [MATCHED_FILE, ANSWER_KEY_FILE, GL_FILE]:
        if not f.exists():
            print(f"❌ Không tìm thấy file: {f}")
            return

    # Đọc dữ liệu
    matched_df = pd.read_csv(MATCHED_FILE)
    truth_df = pd.read_csv(ANSWER_KEY_FILE)
    gl_df = pd.read_csv(GL_FILE)

    total_transactions = len(gl_df)  # Tổng số giao dịch GL
    print(f"Tổng số giao dịch GL để tính Auto-match rate: {total_transactions}")

    # Tính KPI
    auto_match_rate, precision, recall, true_matches = calculate_kpi(matched_df, truth_df, total_transactions)

    print(f"\n📊 KPI:")
    print(f"Auto-match rate : {auto_match_rate:.2f}%")
    print(f"Precision      : {precision:.2f}%")
    print(f"Recall         : {recall:.2f}%")

    # Xuất báo cáo KPI
    kpi_report = pd.DataFrame({
        'Metric': ['Auto-match rate', 'Precision', 'Recall'],
        'Value (%)': [auto_match_rate, precision, recall]
    })
    kpi_report.to_csv(KPI_REPORT_FILE, index=False)
    print(f"\n✓ Đã lưu KPI vào: {KPI_REPORT_FILE}")

    # Xuất chi tiết từng cặp
    details_df = generate_details(matched_df, truth_df)
    details_df.to_csv(KPI_DETAILS_FILE, index=False)
    print(f"✓ Đã lưu chi tiết từng cặp vào: {KPI_DETAILS_FILE}")

    # Latency
    end_time = datetime.now()
    latency = (end_time - start_time).total_seconds()
    print(f"\n⏱ Latency: {latency:.2f} giây")

if __name__ == "__main__":
    main()
