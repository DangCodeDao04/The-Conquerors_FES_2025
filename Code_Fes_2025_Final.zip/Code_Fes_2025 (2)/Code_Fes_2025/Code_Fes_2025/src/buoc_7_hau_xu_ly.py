# -*- coding: utf-8 -*-
"""
Bước 7 — Hậu xử lý lệch (Fee / Partial / Duplicate)
"""
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# === THAM SỐ ===
FEE_THRESHOLD = 100_000         # Ngưỡng phí tối đa
PARTIAL_THRESHOLD = 5           # Số giao dịch tối đa trong 1 nhóm Partial
DUPLICATE_TIME_WINDOW = 3       # Cửa sổ ngày kiểm tra Duplicate
PARTIAL_TOLERANCE = 0.005       # Sai số ±0.5% cho Partial Payment

# === ĐƯỜNG DẪN ===
script_dir = Path(__file__).resolve().parent
root_dir = script_dir.parent
data_dir = root_dir / "data"
output_dir = root_dir / "output"

IN_MATCHES = output_dir / "matched_pairs.csv"
IN_BANK = data_dir / "bank_stmt.csv"
IN_GL = data_dir / "gl_entries.csv"

OUT_ADJUSTED = output_dir / "adjusted_pairs.csv"

# --- HÀM TIỆN ÍCH ---
def classify_status(score):
    if score >= 0.75:
        return 'Matched'
    elif score >= 0.65:
        return 'Review'
    else:
        return 'Unmatched'

# --- XỬ LÝ FEE ADJUSTMENT ---
def detect_fee(matches_df, bank_df):
    fee_list = []
    bank_df['txn_date'] = pd.to_datetime(bank_df['txn_date'])
    unmatched_bank = matches_df[matches_df['match_status']=='Unmatched']

    for _, row in unmatched_bank.iterrows():
        bank_ref = row['bank_ref']
        bank_txn = bank_df[bank_df['ref']==bank_ref]
        if bank_txn.empty:
            continue
        txn = bank_txn.iloc[0]
        desc = str(txn.get('desc_clean','')).lower()
        amount = abs(txn['amount'])
        if amount <= FEE_THRESHOLD or any(word in desc for word in ['fee','phí','phi','charge']):
            # Tìm giao dịch Matched/Review gần ±1 ngày
            txn_date = txn['txn_date']
            candidate = matches_df[
                (matches_df['match_status'].isin(['Matched','Review'])) &
                (pd.to_datetime(bank_df['txn_date']).between(txn_date - timedelta(days=1), txn_date + timedelta(days=1)))
            ]
            if not candidate.empty:
                fee_list.append({
                    'bank_ref': bank_ref,
                    'gl_doc': candidate.iloc[0]['gl_doc'],
                    'match_status': 'Matched',
                    'mismatch_type': 'Fee Adjustment',
                    'note': f'+{amount:,.0f} VND fee'
                })
    return pd.DataFrame(fee_list)

# --- XỬ LÝ PARTIAL PAYMENT ---
def detect_partial(matches_df, bank_df, gl_df):
    partial_list = []
    unmatched = matches_df[matches_df['match_status']=='Unmatched']
    gl_groups = gl_df.groupby('doc_no')

    for _, bank_row in unmatched.iterrows():
        bank_ref = bank_row['bank_ref']
        bank_txn = bank_df[bank_df['ref']==bank_ref]
        if bank_txn.empty:
            continue
        bank_amount = abs(bank_txn.iloc[0]['amount'])

        # Tìm các GL entries có tổng gần bằng bank_amount ±0.5%
        for doc_no, group in gl_groups:
            gl_total = group['amount'].abs().sum()
            if abs(bank_amount - gl_total)/bank_amount <= PARTIAL_TOLERANCE:
                partial_list.append({
                    'bank_ref': bank_ref,
                    'gl_doc': doc_no,
                    'match_status': 'Matched',
                    'mismatch_type': 'Partial Payment',
                    'note': f'{len(group)} sub-txns combined'
                })
                break
    return pd.DataFrame(partial_list)

# --- XỬ LÝ DUPLICATE ---
def detect_duplicate(bank_df):
    dup_list = []
    bank_df['txn_date'] = pd.to_datetime(bank_df['txn_date'])
    for i, row in bank_df.iterrows():
        ref1 = row['ref']
        amount1 = row['amount']
        date1 = row['txn_date']
        # Tìm các giao dịch cùng ngày ± window và cùng amount
        dup_candidates = bank_df[
            (bank_df['ref']!=ref1) &
            (abs(bank_df['amount'] - amount1) < 0.01) &
            (bank_df['txn_date'].between(date1 - timedelta(days=DUPLICATE_TIME_WINDOW),
                                         date1 + timedelta(days=DUPLICATE_TIME_WINDOW)))
        ]
        for _, dup_row in dup_candidates.iterrows():
            dup_list.append({
                'bank_ref': ref1,
                'gl_doc': '-', 
                'match_status': 'Review',
                'mismatch_type': 'Duplicate',
                'note': f'Duplicate with {dup_row["ref"]}'
            })
    return pd.DataFrame(dup_list)

# --- MAIN ---
def main():
    print("\n=== BƯỚC 7: HẬU XỬ LÝ LỆCH ===")

    # 1. Kiểm tra files
    required_files = [IN_MATCHES, IN_BANK, IN_GL]
    for f in required_files:
        if not f.exists():
            print(f"❌ Không tìm thấy file: {f}")
            return

    # 2. Đọc dữ liệu
    matches_df = pd.read_csv(IN_MATCHES)
    bank_df = pd.read_csv(IN_BANK)
    gl_df = pd.read_csv(IN_GL)

    # 3. Đảm bảo các cột cần thiết
    if 'match_score' not in matches_df.columns:
        matches_df['match_score'] = 0.0
    if 'match_status' not in matches_df.columns:
        matches_df['match_status'] = matches_df['match_score'].apply(classify_status)
    if 'bank_ref' not in matches_df.columns:
        matches_df.rename(columns={matches_df.columns[0]:'bank_ref'}, inplace=True)
    if 'gl_doc' not in matches_df.columns:
        matches_df.rename(columns={matches_df.columns[1]:'gl_doc'}, inplace=True)

    # 4. Chạy các module
    fee_adj = detect_fee(matches_df, bank_df)
    partial_adj = detect_partial(matches_df, bank_df, gl_df)
    duplicate_adj = detect_duplicate(bank_df)

    # 5. Gộp kết quả
    all_adj = pd.concat([matches_df[['bank_ref','gl_doc','match_status']].copy(),
                         fee_adj, partial_adj, duplicate_adj], ignore_index=True, sort=False)

    # Điền cột note nếu thiếu
    all_adj['note'] = all_adj.get('note', '-')
    all_adj['mismatch_type'] = all_adj.get('mismatch_type', None)

    # Sắp xếp
    all_adj = all_adj.sort_values(['match_status','mismatch_type'])

    # 6. Ghi file
    all_adj.to_csv(OUT_ADJUSTED, index=False)
    print(f"\n✓ Đã ghi file kết quả: {OUT_ADJUSTED}")

    # In 10 dòng đầu
    print(all_adj.head(10))

if __name__=='__main__':
    main()
