# -*- coding: utf-8 -*-
"""
Bước 8 — Silver Layer: Hybrid Text (BM25 + Embedding)
Phiên bản sửa: xuất đủ các ứng viên chưa matched + review, đảm bảo output silver_candidates.csv đầy đủ
"""

import pandas as pd
import numpy as np
from pathlib import Path
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer, util
import warnings

warnings.filterwarnings('ignore')

# --- Tham số ---
MODEL_NAME = 'intfloat/multilingual-e5-small'
TOP_K = 3
HYBRID_WEIGHT_BM25 = 0.5
HYBRID_WEIGHT_EMBED = 0.5
MIN_SCORE_THRESHOLD = 0.3

# --- Đường dẫn ---
script_dir = Path(__file__).resolve().parent
root_dir = script_dir.parent
data_dir = root_dir / "data"
output_dir = root_dir / "output"

IN_BANK = data_dir / "bank_stmt.csv"
IN_GL = data_dir / "gl_entries.csv"
IN_ADJUSTED = output_dir / "adjusted_pairs.csv"
OUT_SILVER = output_dir / "silver_candidates.csv"

def load_unmatched_review(bank_path, gl_path, adjusted_path):
    """Lấy tất cả bank_ref chưa matched (Review + Unmatched)"""
    bank_df = pd.read_csv(bank_path)
    gl_df = pd.read_csv(gl_path)
    adjusted_df = pd.read_csv(adjusted_path)

    # Chọn bank_ref chưa matched
    to_process = adjusted_df[adjusted_df['match_status'].isin(['Review','Unmatched'])]
    bank_refs = to_process['bank_ref'].unique()

    bank_df['ref'] = bank_df['ref'].astype(str)
    gl_df['doc_no'] = gl_df['doc_no'].astype(str)

    unmatched_bank = bank_df[bank_df['ref'].isin(bank_refs)].copy()
    unmatched_bank['text'] = unmatched_bank['desc'].fillna('').str.lower()
    unmatched_bank['desc'] = unmatched_bank['desc'].fillna('')

    gl_df['text'] = gl_df['partner'].fillna('').str.lower()
    gl_df['partner'] = gl_df['partner'].fillna('')

    return unmatched_bank[['ref','text','desc']], gl_df[['doc_no','text','partner']]

def get_bm25_scores(queries, corpus):
    tokenized_corpus = [c.split() for c in corpus]
    tokenized_queries = [q.split() for q in queries]
    bm25 = BM25Okapi(tokenized_corpus)
    scores = np.array([bm25.get_scores(q) for q in tokenized_queries])
    # Chuẩn hóa
    scores /= np.maximum(scores.max(axis=1, keepdims=True), 1e-6)
    return scores

def get_embedding_scores(model, queries, corpus):
    from torch import tensor
    query_emb = model.encode(queries, convert_to_tensor=True)
    corpus_emb = model.encode(corpus, convert_to_tensor=True)
    sim = util.cos_sim(query_emb, corpus_emb)
    return sim.cpu().numpy()

def get_ground_truth(adjusted_path):
    df = pd.read_csv(adjusted_path)
    matched = df[df['match_status']=='Matched'][['bank_ref','gl_doc']]
    return dict(zip(matched['bank_ref'], matched['gl_doc']))

def calculate_recall(bank_ref, predictions, truth_dict, k=3):
    if bank_ref not in truth_dict: return 0.0
    return 1.0 if truth_dict[bank_ref] in predictions[:k] else 0.0

def main():
    print("=== Bước 8: Silver Layer (Hybrid) ===")
    bank_df, gl_df = load_unmatched_review(IN_BANK, IN_GL, IN_ADJUSTED)
    queries = bank_df['text'].tolist()
    corpus = gl_df['text'].tolist()

    print(f"✓ Bank: {len(queries)}, GL: {len(corpus)}")

    model = SentenceTransformer(MODEL_NAME)
    bm25_scores = get_bm25_scores(queries, corpus)
    embed_scores = get_embedding_scores(model, queries, corpus)
    hybrid_scores = HYBRID_WEIGHT_BM25*bm25_scores + HYBRID_WEIGHT_EMBED*embed_scores

    truth_dict = get_ground_truth(IN_ADJUSTED)
    results = []

    for i, scores in enumerate(hybrid_scores):
        bank_ref = bank_df['ref'].iloc[i]
        bank_desc = bank_df['desc'].iloc[i]
        top_indices = np.argsort(scores)[-TOP_K:][::-1]
        top_docs = [gl_df['doc_no'].iloc[j] for j in top_indices]
        recall = calculate_recall(bank_ref, top_docs, truth_dict, TOP_K)
        for rank, j in enumerate(top_indices):
            score = scores[j]
            if score < MIN_SCORE_THRESHOLD:
                continue
            results.append({
                'bank_ref': bank_ref,
                'gl_doc': gl_df['doc_no'].iloc[j],
                'partner': gl_df['partner'].iloc[j],
                'f_text': round(score,4),
                'Recall@3': recall,
                'Rank': rank+1
            })

    df_out = pd.DataFrame(results).sort_values(['bank_ref','f_text'], ascending=[True,False])
    df_out.to_csv(OUT_SILVER,index=False)
    print(f"✓ Đã lưu {len(df_out)} ứng viên vào {OUT_SILVER}")

if __name__=="__main__":
    main()
